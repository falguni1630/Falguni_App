# bank

working on creating a bank portal that allows users to register, login, and view their account information, along with transaction history for their accounts.